import time
import json

def job():
    with open('log.json', 'wt') as f:
    	json.dump({'message': 'Testing - if this is printed that means it is working 1'}, f)
    time.sleep(10)
    with open('log.json', 'wt') as f:
       json.dump({'message': 'Testing - if this is printed that means it is working 2'}, f)
    time.sleep(60)
    with open('log.txt', 'wt') as f:
        json.dump({'message': 'Testing - if this is printed that means it is working 3'}, f)


if __name__ == '__main__':
    job()
