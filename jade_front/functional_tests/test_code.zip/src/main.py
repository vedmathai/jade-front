import time

def job():
    with open('testing.txt', 'wt') as f:
        f.write('Testing - if this is printed that means it is working 1')
    time.sleep(10)
    with open('testing.txt', 'wt') as f:
        f.write('Testing - if this is printed that means it is working 2')
    time.sleep(60)
    with open('testing.txt', 'wt') as f:
        f.write('Testing - if this is printed that means it is working 3')


if __name__ == '__main__':
    job()